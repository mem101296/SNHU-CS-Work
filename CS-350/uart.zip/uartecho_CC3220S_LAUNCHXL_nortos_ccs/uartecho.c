/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uartecho.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char        input;
    const char  echoPrompt[] = "Echoing characters:\r\n";
    const char  startPrompt[] = "Please turn LED ON or OFF:\r\n";
    UART_Handle uart;
    UART_Params uartParams;

    /* Call driver init functions */
    GPIO_init();
    UART_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;     /*!< Type of data being written */
    uartParams.readDataMode = UART_DATA_BINARY;      /*!< Type of data being read */
    uartParams.readReturnMode = UART_RETURN_FULL;    /*!< Receive return mode */
    uartParams.baudRate = 115200;                    /*!< Baud rate for UART */

    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }

    /* Turn on user LED to indicate successful initialization */
    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  /*Writes the value to a GPIO pin (GPIO index, must be either 0 or 1)*/
    //commenting out to have LED start in OFF state

    /*UART_write(uart, echoPrompt, sizeof(echoPrompt));*/ //removes to use custom welcome prompt

    UART_write(uart, startPrompt, sizeof(startPrompt)); //Prints custom welcome prompt

    enum LED0_States {led_start, led_nf, led_f2, led_on, led_off} LED0_State;


    /* Loop forever echoing */
    while (1) {

            UART_read(uart, &input, 1);
            //////////////////////////
            switch(LED0_State) {//transitions
                //|||//
                case led_start: //Initial transition
                    if(input == 'O') { //checks for 0
                        LED0_State = led_nf; //sets state to lednf - or led o f
                    }
                    break;
                //|||//
                case led_nf:
                    if(input == 'N') { //checks for n
                        LED0_State = led_on; //sets state to led_on
                    }
                    else if(input == 'F') { //if no n, checks for f
                        LED0_State = led_f2; //sets state to led_f2
                    }
                    break;
                //|||//
                case led_f2:
                    if(input == 'F') { //checks for second f
                        LED0_State = led_off; //sets state to led_off
                    }
                    break;
                //|||//
                default:
                    LED0_State = led_start; //sets to led_start if no case runs
                    break;
                }

            //////////////////////////
            switch(LED0_State) { //State actions
            //|||//
            case led_on: //led on action
                GPIO_write(CONFIG_GPIO_LED_0_CONST, CONFIG_GPIO_LED_ON);
                LED0_State = led_start;
                break;
            //|||//
            case led_off: //led off action
                GPIO_write(CONFIG_GPIO_LED_0_CONST, CONFIG_GPIO_LED_OFF);
                LED0_State = led_start;
                break;
            }

           //////////////////////////
           UART_write(uart, &input, 1);

    }
}
